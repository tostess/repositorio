package model;

public class Serie  implements java.io.Serializable {
     private Integer id;
     private String serie;
     private Integer temporadas;
     private String emissora;
     private Integer episodios;
     private Float classificacao;
     private Boolean status;
     private String img = null;

    public Serie() {
    }

	
    public Serie(String serie) {
        this.serie = serie;
    }
    public Serie(String serie, Integer temporadas, String emissora, Integer episodios, Float classificacao, Boolean status, String img) {
       this.serie = serie;
       this.temporadas = temporadas;
       this.emissora = emissora;
       this.episodios = episodios;
       this.classificacao = classificacao;
       this.status = status;
       this.img = img;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getSerie() {
        return this.serie;
    }
    
    public void setSerie(String serie) {
        this.serie = serie;
    }
    public Integer getTemporadas() {
        return this.temporadas;
    }
    
    public void setTemporadas(Integer temporadas) {
        this.temporadas = temporadas;
    }
    public String getEmissora() {
        return this.emissora;
    }
    
    public void setEmissora(String emissora) {
        this.emissora = emissora;
    }
    public Integer getEpisodios() {
        return this.episodios;
    }
    
    public void setEpisodios(Integer episodios) {
        this.episodios = episodios;
    }
    public Float getClassificacao() {
        return this.classificacao;
    }
    
    public void setClassificacao(Float classificacao) {
        this.classificacao = classificacao;
    }
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }
    public String getImg() {
        return this.img;
    }
    
    public void setImg(String img) {
        this.img = img;
    }

    public boolean temImg() {
       return this.img != null && !this.img.trim().isEmpty();
    }


}


